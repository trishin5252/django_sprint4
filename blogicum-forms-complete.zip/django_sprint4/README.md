# Блогикум — формы, пользователи и комментарии

Готовый Django-проект. Шаблоны Практикума сохранены без изменений.

## Запуск

Рекомендуется Python 3.10.

```sh
python -m venv venv
# Windows: venv\Scripts\activate
pip install -r requirements.txt
cd blogicum
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver --insecure
```

Для разработки установите DEBUG = True в blogicum/settings.py.
Для проверки: из корня репозитория выполните `pytest` и `flake8 blogicum`.
Пользовательские изображения сохраняются в media/, письма — в sent_emails/.

Результат проверки: 25 тестов Практикума пройдены, flake8 без ошибок.
Архив подготовлен локально. На GitHub и преподавателю не отправлялся.
